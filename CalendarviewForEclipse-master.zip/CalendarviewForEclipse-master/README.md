# CalendarviewForEclipse
直接导入到eclipse里面即可, 这个是根据这个项目（https://github.com/huanghaibin-dev/CalendarView） 修改而来的. 
###
在此非常感谢原作者，还亲自远程帮我解决了很多问题。
###
我的QQ 2269597593 ，有问题可以联系我啊。

### 月份效果
<img src="https://github.com/yuer01/CalendarviewForEclipse/blob/master/xiaoguo2/1.png?raw=true" height="650"/>

### 星期效果
<img src="https://github.com/yuer01/CalendarviewForEclipse/blob/master/xiaoguo2/2.png?raw=true" height="650"/>
